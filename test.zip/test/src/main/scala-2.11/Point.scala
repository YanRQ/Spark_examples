/**
  * Created by andy on 3/17/16.
  */
object Point {
  def random() = {
    new Point(math.random * 100, math.random * 100)
  }
}

case class Point(val x: Double, val y: Double) {
  def +(that: Point) = new Point(this.x + that.x, this.y + that.y)
  def -(that: Point) = new Point(this.x - that.x, this.y - that.y)
  def /(d: Double) = new Point(this.x / d, this.y / d)
  def pointLength = math.sqrt(x * x + y * y)
  def distance(that: Point) = (this - that).pointLength

  def format(x: Double, y: Double): String = "(" + x.toString + "," +y.toString + ")"
  override def toString = format(x, y)
}


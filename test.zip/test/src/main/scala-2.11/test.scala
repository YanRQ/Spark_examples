/**
  * Created by sgf on 2016/1/20.
  */
//package org.jblas


import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.mllib.linalg.Vectors
import java.io._

import org.jblas.DoubleMatrix

//import org.jblas.DoubleMatrix

/**
  * A simple Spark app in Scala
  */

object test {
/*
  def main(args: Array[String]) {
//    val aMatrix = new DoubleMatrix(Array(1.0, 2.0, 3.0))

    //    val conf = new SparkConf().setMaster("local").setAppName("simpleApp")
    //    val sc = new SparkContext(conf)
    val sc = new SparkContext("local[2]", "simpleApp")
    // we take the raw data in CSV format and convert it into a set of records of the form (user, product, price)
    val data = sc.textFile("/Users/andy/IdeaProjects/test/data/1.csv").map(line => line.split(",")).map(purchaseRecord => (purchaseRecord(0), purchaseRecord(1), purchaseRecord(2)))
    // let's count the number of purchases
    val numPurchases = data.count()
    // let's count how many unique users made purchases
    val uniqueUsers = data.map{ case (user, product, price) => user}.distinct().count()
    // let's sum up our total revenue
    val totalRevenue = data.map{ case (user, product, price) => price.toDouble }.sum()
    // let's find our most popular product
    val productsByPopularity = data.map{ case (user, product, price) => (product, 1) }.reduceByKey(_ + _).collect().sortBy(+_._2)
    val mostPopular = productsByPopularity(0)
    println("Total purchases: " + numPurchases)
    println("Unique users: " + uniqueUsers)
    println("Total revenue: " + totalRevenue)
    println("Most popular product: %s with %d purchases".format(mostPopular._1, mostPopular._2))

    /*
    val broadcastAList = sc.broadcast(List("a","b","c","d","e"))
    val data = sc.parallelize(List("1","2","3")).map(x=>broadcastAList.value ++x).collect
    data.foreach(println)*/
  }



  def main(args: Array[String]) {
    val master = args.length match {
      case x: Int if x > 0 => args(0)
      case _ => "local"
    }
    val sc = new SparkContext(master, "BasicAvg", System.getenv("SPARK_HOME"))
    val input = sc.parallelize(List(1,2,3,4))
    val result = computeAvg(input)
    val avg = result._1 / result._2.toFloat
    println(result)
  }
  def computeAvg(input: RDD[Int]) = {
    input.aggregate((0, 0))((x, y) => (x._1 + y, x._2 + 1),
      (x,y) => (x._1 + y._1, x._2 + y._2))
  }

  */


def main(args: Array[String]): Unit = {
  //val conf = new SparkConf().setMaster("local").setAppName("simpleApp")
  //val sc = new SparkContext(conf)
  val sc = new SparkContext("local[2]", "simpleApp")
  val rawData = sc.textFile("/Users/andy/Downloads/ml-1m/movies.dat")

  val rawRatings = sc.textFile("/Users/andy/Downloads/ml-1m/ratings.dat")

  //val rawUsers = sc.textFile("/Users/andy/Downloads/ml-1m/users.dat")

  val records= rawData.map(line=>line.split("::"))

  val titles =rawData.map(line=>line.split("::").take(2)).map(array=>
    (array(0).toInt,array(1))).collectAsMap()

  val rawCategories = records.map(r => r(2)).flatMap(line=>line.split("\\|"))

  val categories = rawCategories.distinct.collect.zipWithIndex.toMap

  val numCategories = categories.size
  //println(categories)


  //val testR = records.map(r =>r(0),r(1),r(2).split("\\|"))

  val dataCategories = records.map{ r =>
    val label =r(0).toInt
    val categoryIdx = r(2).split("\\|").map(d => categories(d))
    val categoryFeatures = Array.ofDim[Double](numCategories)
    for(i <- 0 until categoryIdx.length -1) categoryFeatures(categoryIdx(i)) = 1.0
    LabeledPoint(label, Vectors.dense(categoryFeatures))
  }
  dataCategories.take(2).foreach(println)

  val movieCategories = {
    records.flatMap(r => Array(r(2).split("\\|").map(d => categories(d)))).collect
  }

  //moviesForUser


  val ratings = rawRatings.map(line =>line.split("::")).map(r => (r(0).toInt, r(1).toInt))

  Array(ratings)

  val moviesOfUser = {
    ratings.combineByKey((v: Int) => List(v), (c: List[Int], v: Int) => v :: c, (c1: List[Int], c2: List[Int]) => c1 ::: c2)
  }

  //val movie_user = sc.parallelize(moviesOfUser)


  val userCategories = moviesOfUser.map{ r =>
    val label = r._1.toInt
    val allMovies =r._2
    val categoryFeatures = Array.ofDim[Double](numCategories)
    for(i <- 0 until allMovies.length - 1) {
      val m = movieCategories(i)
      val l =m.length
      for(j <- 0 until l -1) {
        val n = m(j)
        val k = 1.0/l
        categoryFeatures(n) += k
      }
    }
    //categoryFeatures=categoryFeatures/allMovies.length;
    //LabeledPoint(label, Vectors.dense(categoryFeatures))
    (label, Array(categoryFeatures))
    //Array(label, categoryFeatures)
  }
  //userCategories.take(3).foreach(println)
  // userCategories.saveAsTextFile("/Users/andy/Downloads/ml-1m/test.txt")
  //val u1 = userCategories.lookup(1)
  /*userCategories.lookup(2672).foreach(println)
  userCategories.lookup(3694).foreach(println)
  userCategories.lookup(2452).foreach(println)
  userCategories.lookup(2948).foreach(println)
  userCategories.lookup(2300).foreach(println)*/

  val numUsers = userCategories.count().toInt
  for(h<-1 to numUsers) {
    val itemFactor = userCategories.lookup(h).head
    val itemVector = new DoubleMatrix(itemFactor)

    val sims = userCategories.map { case (id, factor) =>
      val factorVector = new DoubleMatrix(factor)
      val sim = cosineSimilarity(factorVector,itemVector)
      (id , sim)
    }
    val sortedSims =sims.top(30)(Ordering.by[(Int, Double),Double]{
      case (id, similarity)=>similarity
    })
    println(sortedSims.take(30).mkString("\n"))
  }
  val ratings2 = rawRatings.map(_.split("::").take(3))
  val moviesForUser =ratings2.map{
    case Array(user, movie, rating) =>(user.toInt, movie.toInt, rating.toDouble)
  }

  val moviesForUser2 = moviesForUser.keyBy(_._1).lookup(2672)
  //moviesForUser2.sortBy(-_._3).take(10).map(_ => (titles(_._2),_._3)) .foreach(println)

/*
  val writer = new PrintWriter(new File("/Users/andy/Downloads/ml-1m/test.txt"))
  writer.write("OK ")
  writer.write(userCategories.take(10).toString)
  writer.close()*/
}

  def out(arr:Array[Double]){
    val len =arr.length
    for(i<- 0 to len -1)
      println(arr(i))
  }

  def cosineSimilarity(vec1:DoubleMatrix,vec2:DoubleMatrix):Double ={
    vec1.dot(vec2)/(vec1.norm2() * vec2.norm2())
  }

}

